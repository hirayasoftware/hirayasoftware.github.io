#encoding=utf-8
import sys
import xbmcgui
import xbmcplugin
import xbmc
import urllib
import urllib2
import urlparse
import xbmcaddon
import os
import unicodedata
import plugintools
import requests
import json
from HTMLParser import HTMLParser
from types import UnicodeType
 
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
my_addon = xbmcaddon.Addon()
PATH = my_addon.getAddonInfo('path')
sys.path.append(xbmc.translatePath(os.path.join(PATH, 'lib')))

channellist = [
    [
        "user/TVG",
        "https://yt3.ggpht.com/a/AGF-l7_J2rNU1SxLIhuRUKfQS5uwmRWqU2owzFb8BQ=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Televisión de Galicia"
    ],[
        "channel/UCNb3tjKhzqyMC2auS7d2kCg",
        "https://yt3.ggpht.com/a/AGF-l78jOoAQANgRdB0Sjua9e-qkb8ryhIGw7omZcg=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Pasouoquepasou.crtvg"
    ],[
        "channel/UCVm7KnwW4Wcivk1XI_qlv8g",
        "https://yt3.ggpht.com/a/AGF-l7_vuPT_yGwTds69ThIqc62BuVH6l9F5tZ1rZA=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - A Tarde"
    ],[
        "channel/UCrRMzy3wEZRREgaoBeYG8vg",
        "https://yt3.ggpht.com/a/AGF-l7-wkWAvpYuiCHLID7X57cWYpJjsc0cBFQTRvw=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - enserie"
    ]
]

def utf8me(string_in):
    return safe_unicode(string_in).encode('utf-8')

def safe_unicode(value):
    if type(value) is UnicodeType:
        return value
    else:
        try:
            return unicode(value, 'utf-8')
        except:
            return unicode(value, 'iso-8859-1')
 
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def decode_html(value):
    try:
        unicode_title = unicode(value, "utf8", "ignore")
        text_out = utf8me(HTMLParser().unescape(unicode_title).encode("utf8"))
    except:
        text_out = utf8me(value)

    return text_out.replace('&amp;', '&').replace('&quot;', '"').replace('&#039;', '"')

def browse_this_shit(url_in):
    try:
        request = urllib2.Request(url_in)
        return urllib2.urlopen(request).read()
    except:
        return browse_this_shit(url_in)

mode = args.get('mode', None)

if mode is None:
    index_html = browse_this_shit('http://www.crtvg.es/tvg/a-carta')
    a = index_html.split('<!-- LISTADO POR CATEGORÍAS -->')
    b = a[1].split('<div id="footer">')
    c = b[0].split('<h3>')
    for x in range(1, len(c)):
        d = c[x].split('</h3>')
        indice = d[0].strip()
        url = build_url({'mode': 'indice', 'title': decode_html(indice), 'href': indice})
        li = xbmcgui.ListItem(decode_html(indice), iconImage = PATH + '/icon.png')
        li.setInfo(type="Video", infoLabels={"plot": decode_html(indice)})
        li.setArt({'fanart': PATH + '/fanart.jpg'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    channellist = sorted(channellist, key = lambda i: i[2],reverse=False)
    for id, icon, name in channellist:
        plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,folder=True)
    xbmcplugin.endOfDirectory(addon_handle)
    
elif mode[0] == 'indice':
    index_html = browse_this_shit('http://www.crtvg.es/tvg/a-carta')
    a = index_html.split('<!-- LISTADO POR CATEGORÍAS -->')
    b = a[1].split('<div id="footer">')
    c = b[0].split('<h3>')
    for x in range(1, len(c)):
        d = c[x].split('</h3>')
        if d[0].strip() == args['title'][0]:
            e = c[x].split('<a href="')
            for y in range(1, len(e)):
                f = e[y].split('"')
                g = e[y].split('title="')
                h = g[1].split('">')
                if h[0] != '':
                    url = build_url({'mode': 'show', 'title': decode_html(h[0]), 'href': f[0]})
                    li = xbmcgui.ListItem(decode_html(h[0]), iconImage = PATH + '/icon.png')
                    li.setInfo(type="Video", infoLabels={"plot": decode_html(h[0])})
                    li.setArt({'fanart': PATH + '/fanart.jpg'})
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            break
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'show':
    show_html = browse_this_shit('http://www.crtvg.es' + args['href'][0])
    a = show_html.split('initAlaCartaBuscador(')
    b = a[1].split(');')
    c = b[0].split(',')
    headers = {
        'Pragma': 'no-cache',
        'Origin': 'http://www.crtvg.es',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'es-ES,es;q=0.9',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Cache-Control': 'no-cache',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Referer': 'http://www.crtvg.es' + args['href'][0],
        'Content-Length': '0',
    }
    p = 1
    while True:
        response = requests.post('http://www.crtvg.es/ax/tvgalacartabuscador/programa:' + c[0].strip() + '/pagina:' + str(p) + '/seccion:' + c[2].strip() + '/titulo:/mes:null/ano:null/temporada:null/pcompleto:null', headers=headers, verify=False).text
        if 'Non se atopou' in response:
            break
        else:
            json_response = json.loads(response)
            d = json_response['listado'].split('<a href="')
            for x in range(1, len(d)):
                e = d[x].split('"')
                f = d[x].split('title="')
                g = f[1].split('"')
                h = d[x].split('data">')
                i = h[1].split('</td>')
                url = build_url({'mode': 'play', 'title': decode_html(g[0]), 'href': e[0]})
                li = xbmcgui.ListItem(decode_html(i[0].strip() + ' - ' + g[0]), iconImage = PATH + '/icon.png')
                li.setInfo(type="Video", infoLabels={"plot": decode_html(g[0])})
                li.setArt({'fanart': PATH + '/fanart.jpg'})
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            p = p + 1
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'play':
    video_html = browse_this_shit('http://www.crtvg.es' + args['href'][0])
    a = video_html.split('var url = "')
    b = a[1].split('"')
    listitem = xbmcgui.ListItem(args['title'][0])
    listitem.setInfo('video', {'Title': args['title'][0]})
    xbmc.Player().play(b[0] + '/playlist.m3u8', listitem)