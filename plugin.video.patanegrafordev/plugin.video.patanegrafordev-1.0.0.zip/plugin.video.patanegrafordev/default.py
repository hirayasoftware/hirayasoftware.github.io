# encoding=utf8
import sys
reload(sys)
sys.setdefaultencoding('utf8')
import xbmcgui
import xbmcplugin
import xbmc
import urllib
import urllib2
import requests
import urlparse
import json
import xbmcaddon
import os
import re
import base64
import unicodedata
import urlresolver
import resolveurl
import random
import plugintools
import zipfile

from HTMLParser import HTMLParser
from sources import pelis28, peliculasmaniac, cuevana2, cliver, pelisencastellano, dixmax, extra, gnulapro, estrenosflix, cineonline, pelisplanet, pepecine, pelisplusgo, verpelisonline, peliculasgolden, verpeliculasultra, pelisgratis, fullpeliculashd, entrepeliculasyseries, pelispedia, pelisplay
from types import UnicodeType
from sqlite3 import dbapi2 as database
from datetime import datetime, timedelta
from threading import Thread
from lib import youtube_dl
from resolveurl.plugins.lib import jsunpack

import time
 
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
my_addon = xbmcaddon.Addon()
PATH = my_addon.getAddonInfo('path')

cache_location = os.path.join(xbmc.translatePath("special://database"), 'patanegra.db')
lib_location = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode("utf-8")
posters_location = lib_location + 'posters'
dbcon = database.connect(cache_location)
dbcur = dbcon.cursor()


def check_poster_dir():
    if my_addon.getSetting('config_images') == 'true':
        if os.path.isdir(posters_location) == False:
            os.mkdir(posters_location)

def view(name):

    if name == 0:
        return '55'
    if name == 2:
        return '51'
    if name == 3:
        return '53'
    if name == 5:
        return '54'
    if name == 1:
        return '50'
    if name == 4:
        return '500'

def strip_accents(text):
    try:
        text = unicode(text.encode("utf-8"), 'utf-8')
    except NameError:
        pass
    text = unicodedata.normalize('NFD', text)\
           .encode('ascii', 'ignore')\
           .decode("utf-8")
    return str(text)

def only_legal_chars(string_in):
    string_out = strip_accents(string_in)
    string_out = re.sub(r'[\\/:"*?<>|]+', "", string_out)
    string_out = "".join(i for i in string_out if ord(i)<128)
    string_out = ' '.join(string_out.split())
    return string_out

def three_char_num(n_in):
    if len(n_in) == 1:
        return '00' + n_in
    elif len(n_in) == 2:
        return '0' + n_in
    else:
        return n_in

def tmdb_query(url_in):
    dbcur.execute("CREATE TABLE IF NOT EXISTS tmdb_queries (url TEXT, json TEXT, expire INT, UNIQUE(url));")
    dbcon.commit()
    dbcur.execute("DELETE FROM tmdb_queries WHERE expire < " + datetime.now().strftime("%Y%m%d%H%M%S"))
    dbcon.commit()
    dbcur.execute("SELECT json FROM tmdb_queries WHERE url = '" + url_in + "' AND expire > " + datetime.now().strftime("%Y%m%d%H%M%S"))
    match = dbcur.fetchone()
    if match != None:
        return json.loads(base64.b64decode(match[0]))
    else:
        request = urllib2.Request(url_in)
        data = json.loads(urllib2.urlopen(request).read())
        expiration = datetime.now() + timedelta(hours=int(my_addon.getSetting('config_cache')))
        dbcur.execute('INSERT INTO tmdb_queries VALUES("' + url_in + '", "' + base64.b64encode(json.dumps(data)) + '", ' + expiration.strftime("%Y%m%d%H%M%S") + ')')
        dbcon.commit()
        return data
 
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def pretty_sources(source_in):
    source_out = source_in.lower()
    if 'google' in source_out:
        source_out = 'Google Drive'
    if 'fembed' in source_out:
        source_out = 'Fembed'
    if 'gamovideo' in source_out:
        source_out = 'Gamovideo'
    if 'gounlimited' in source_out:
        source_out = 'Gounlimited'
    if 'kiripiliar' in source_out:
        source_out = 'Kiripiliarload'
    if 'ok.ru' in source_out:
        source_out = 'Ok.ru'
    if 'streamango' in source_out:
        source_out = 'Streamango'
    
    if 'cdnrapidvideo' in source_out:
        source_out = 'CDN Rapidvideo'
    elif 'rapidvideo' in source_out:
        source_out = 'Rapidvideo'
    
    if 'openload' in source_out:
        source_out = 'Openload'
    if 'ultrastream' in source_out:
        source_out = 'Ultrastream'
    if 'vidoza' in source_out:
        source_out = 'Vidoza'
    if 'userscloud' in source_out:
        source_out = 'Userscloud'
    if 'verystream' in source_out:
        source_out = 'Verystream'
    if 'streamplay' in source_out:
        source_out = 'Streamplay'
    if 'flashx' in source_out:
        source_out = 'Flashx'
    if 'streamcherry' in source_out:
        source_out = 'Streamcherry'
    if 'powv' in source_out:
        source_out = 'Powvideo'
    if 'hqq' in source_out:
        source_out = 'Hqq'
    if source_out == 'ul':
        source_out = 'Ul'
    if 'uploaded' in source_out:
        source_out = 'Uploaded'
    if 'katfile' in source_out:
        source_out = 'Katfile'
    if '1fichier' in source_out:
        source_out = '1fichier'
    if 'rapidgator' in source_out:
        source_out = 'Rapidgator'
    if 'thevid' in source_out:
        source_out = 'Thevid'
    if 'vidspot' in source_out:
        source_out = 'Vidspot'
    if 'uqload' in source_out:
        source_out = 'Uqload'
    if 'fastplay' in source_out:
        source_out = 'Fastplay'
    if 'jetload' in source_out:
        source_out = 'Jetload'
    if 'streamvips' in source_out:
        source_out = 'Streamvips'
    if 'megavips' in source_out:
        source_out = 'Megavips'
    if 'mega.nz' in source_out:
        source_out = 'Mega'
    if 'vidlox' in source_out:
        source_out = 'Vidlox'
    if 'byter.tv' in source_out:
        source_out = 'Byter'
    if 'uptostream' in source_out:
        source_out = 'Uptostream'
    if 'webtor' in source_out:
        source_out = 'Webtor'
    if 'seedr' in source_out:
        source_out = 'Seedr'
    if 'directo' in source_out:
        source_out = 'Directo'
    if 'streamp1ay' in source_out:
        source_out = 'Streamplay'
    if 'waaw' in source_out:
        source_out = 'Waaw'
    if 'mixdrop' in source_out:
        source_out = 'Mixdrop'
    if 'clipwatching' in source_out:
        source_out = 'Clipwatching'
    if 'zembed' in source_out:
        source_out = 'Zembed'
    if 'upstream' in source_out:
        source_out = 'Upstream'
    if 'onlystream' in source_out:
        source_out = 'Onlystream'
    if 'youtube' in source_out:
        source_out = 'Youtube'
    if 'prostream' in source_out:
        source_out = 'Prostream'
    if 'cloudvideo' in source_out:
        source_out = 'Cloudvideo'
    if 'vidtodo' in source_out:
        source_out = 'Vidtodo'
    if 'upvid' in source_out:
        source_out = 'Upvid'
    if 'videobin' in source_out:
        source_out = 'Videobin'
    if 'vidia' in source_out:
        source_out = 'Vidia'
    if 'netu' in source_out:
        source_out = 'Netu'
    if 'uptobox' in source_out:
        source_out = 'Uptobox'
    if 'nitroflare' in source_out:
        source_out = 'Nitroflare'
    if 'dailymotion' in source_out:
        source_out = 'Dailymotion'
    if 'streamcloud' in source_out:
        source_out = 'Streamcloud'
    if 'nowvideo' in source_out:
        source_out = 'Nowvideo'
    if 'streamin.to' in source_out:
        source_out = 'Streamin'
    if 'allmyvideos' in source_out:
        source_out = 'Allmyvideos'
    if 'vimple' in source_out:
        source_out = 'Vimple'
    if 'goo.gl' in source_out:
        source_out = 'Google Drive'
    if 'played.to' in source_out:
        source_out = 'Played'
    if 'megaup.net' in source_out:
        source_out = 'Megaup'
    if 'rapivideo' in source_out:
        source_out = 'Rapivideo'
    if 'uploadmp4' in source_out:
        source_out = 'Uploadmp4'
    if 'megavideo' in source_out:
        source_out = 'Mega'
    if source_out == 'ok':
        source_out = 'Ok.ru'
    if 'vev.io' in source_out:
        source_out = 'Vev'
    if 'dmca' in source_out:
        source_out = 'dmca'
    if 'allzvids' in source_out:
        source_out = 'Vidtodo'
    if 'videomega' in source_out:
        source_out = 'Videomega'
    if 'rocvideo' in source_out:
        source_out = 'Rocvideo'
    if 'stream-mx' in source_out:
        source_out = 'Stream-mx'
    if 'rapidvid' in source_out:
        source_out = 'Rapidvid'
    if 'videobb' in source_out:
        source_out = 'Videobb'
    if 'rockfile' in source_out:
        source_out = 'Rockfile'
    if source_out == 'toni':
        source_out = 'Toni'
    if source_out == 'mikel':
        source_out = 'MiKeL'
    if source_out == 'jorge':
        source_out = 'Jorge'
    if source_out == 'alex303':
        source_out = 'Alex303'
    if source_out == 'daqueenqueen':
        source_out = 'DaQueenQueen'
    if source_out == 'iberika':
        source_out = 'Iberika'

    return source_out
    #return source_out.capitalize()

def safe_unicode(value):
    if type(value) is UnicodeType:
        return value
    else:
        try:
            return unicode(value, 'utf-8')
        except:
            return unicode(value, 'iso-8859-1')

def play_bso():

    bsos = requests.get('https://pastebin.com/raw/NbnZWpa5').text.split("\n")

    bso = bsos[random.randint(0,len(bsos)-1)].split('#')

    finally_playing = 0

    vuelta = 0

    ydl_opts = {'format': 'bestaudio/best','postprocessors': [{'key': 'FFmpegExtractAudio','preferredcodec': 'mp3'}]}

    ydl = youtube_dl.YoutubeDL(ydl_opts)

    result = ydl.extract_info('https://www.youtube.com/watch?v=' + bso[1].strip(), download=False)
    video_urls = []
    if "ext" in result and "url" in result:
        url_is = safe_unicode(result['url']).encode('utf-8')
        if 'manifest.' in url_is:
            mas = urllib2.urlopen(url_is).read().split('<BaseURL>')
            for mm in range(1, len(mas)):
                mm2 = mas[mm].split('</BaseURL>')
                video_urls.append(safe_unicode(mm2[0]).encode('utf-8'))
        else:
            video_urls.append(safe_unicode(result['url']).encode('utf-8'))
    else:
        if "entries" in result:
            for entry in result["entries"]:
                url_is = safe_unicode(entry['url']).encode('utf-8')
                if 'manifest.' in url_is:
                    mas = urllib2.urlopen(url_is).read().split('<BaseURL>')
                    for mm in range(1, len(mas)):
                        mm2 = mas[mm].split('</BaseURL>')
                        video_urls.append(safe_unicode(mm2[0]).encode('utf-8'))
                else:
                    video_urls.append(safe_unicode(entry['url']).encode('utf-8'))

    

    listitem = xbmcgui.ListItem('BSO ' + bso[0])
    listitem.setInfo(type="Music", infoLabels={'Title' : 'BSO ' + bso[0]})

    for vu in range(0, len(video_urls)):
        if vu == 0:
            kill_vol()

        xbmc.Player().play(video_urls[vu],listitem)

        xbmc.sleep(2000)

        if xbmc.Player().isPlaying():
            up_vol()
            break


def play_this_song_yt(title_in, title_esp):

    title_esp = 'BSO ' + title_esp

    igual = 0

    if xbmc.Player().isPlaying():
        try:
            titulo_player = xbmc.Player().getMusicInfoTag().getTitle()
            if titulo_player == title_esp:
                igual = 1
        except:
            pass

    if igual == 0:

        try:

            finally_playing = 0

            xbmc.sleep(random.randint(1000,2500))
            yt_html_res = urllib2.urlopen("http://www.youtube.com/results?search_query=" + only_legal_chars(title_in.lower()).replace(' ', '+') + "+movie+ost&sp=EgIQAQ%253D%253D").read()
            parts = yt_html_res.split('data-context-item-id="')

            vuelta = 0

            for p in range(1, len(parts)):

                if 'trailer' not in parts[p].lower() and 'review' not in parts[p].lower() and 'трейлер' not in parts[p]:

                    a = parts[p].split('"')
                    id_video = a[0]

                    ydl_opts = {'format': 'bestaudio/best','postprocessors': [{'key': 'FFmpegExtractAudio','preferredcodec': 'mp3'}]}

                    ydl = youtube_dl.YoutubeDL(ydl_opts)
                    result = ydl.extract_info('https://www.youtube.com/watch?v=' + id_video, download=False)
                    video_urls = []
                    if "ext" in result and "url" in result:
                        url_is = safe_unicode(result['url']).encode('utf-8')
                        if 'manifest.' in url_is:
                            mas = urllib2.urlopen(url_is).read().split('<BaseURL>')
                            for mm in range(1, len(mas)):
                                mm2 = mas[mm].split('</BaseURL>')
                                video_urls.append(safe_unicode(mm2[0]).encode('utf-8'))
                        else:
                            video_urls.append(safe_unicode(result['url']).encode('utf-8'))
                    else:
                        if "entries" in result:
                            for entry in result["entries"]:
                                url_is = safe_unicode(entry['url']).encode('utf-8')
                                if 'manifest.' in url_is:
                                    mas = urllib2.urlopen(url_is).read().split('<BaseURL>')
                                    for mm in range(1, len(mas)):
                                        mm2 = mas[mm].split('</BaseURL>')
                                        video_urls.append(safe_unicode(mm2[0]).encode('utf-8'))
                                else:
                                    video_urls.append(safe_unicode(entry['url']).encode('utf-8'))

                    if vuelta == 0:
                        vuelta = 1
                        kill_vol()

                    listitem = xbmcgui.ListItem(title_esp)
                    listitem.setInfo(type="Music", infoLabels={'Title' : title_esp})

                    for vu in range(0, len(video_urls)):
                        xbmc.Player().play(video_urls[vu],listitem)

                        xbmc.sleep(2000)

                        if xbmc.Player().isPlaying():
                            finally_playing = 1
                            up_vol()
                            break
                    if finally_playing == 1:
                        break
                
            return finally_playing
        except:
            return 0

def kill_vol():
    decrease = 100
    for i in range(0, 100):
        xbmc.sleep(50)
        xbmc.executebuiltin('SetVolume(' + str(decrease - i) + ')')

def up_vol():
    for i in range(0, 100):
        xbmc.sleep(50)
        xbmc.executebuiltin('SetVolume(' + str(i) + ')')

def get_sources_from(server_in, id_peli_in, titulo_peli_in):

    cache_location = os.path.join(xbmc.translatePath("special://database"), 'patanegra.db')
    dbcon = database.connect(cache_location)
    dbcur = dbcon.cursor()

    try:
        if server_in == 'dixmax':
            var_sources = dixmax.Dixmax(titulo_peli_in, id_peli_in)
        if server_in == 'cinetux':
            var_sources = cinetux.Cinetux(titulo_peli_in)
        if server_in == 'extra':
            var_sources = extra.Extra(titulo_peli_in, id_peli_in)
        if server_in == 'gnulapro':
            var_sources = gnulapro.Gnulapro(titulo_peli_in)
        if server_in == 'movidy':
            var_sources = movidy.Movidy(titulo_peli_in, id_peli_in)
        if server_in == 'pctnew':
            var_sources = pctnew.Pctnew(titulo_peli_in)
        if server_in == 'estrenosflix':
            var_sources = estrenosflix.Estrenosflix(titulo_peli_in)
        if server_in == 'cineonline':
            var_sources = cineonline.Cineonline(titulo_peli_in)
        if server_in == 'pelisplanet':
            var_sources = pelisplanet.Pelisplanet(titulo_peli_in)
        if server_in == 'pepecine':
            var_sources = pepecine.Pepecine(titulo_peli_in)
        if server_in == 'pelisplusgo':
            var_sources = pelisplusgo.Pelisplusgo(titulo_peli_in)
        if server_in == 'verpelisonline':
            var_sources = verpelisonline.Verpelisonline(titulo_peli_in)
        if server_in == 'peliculasgolden':
            var_sources = peliculasgolden.Peliculasgolden(titulo_peli_in)
        if server_in == 'inkapelis':
            var_sources = inkapelis.Inkapelis(titulo_peli_in)
        if server_in == 'verpeliculasultra':
            var_sources = verpeliculasultra.Verpeliculasultra(titulo_peli_in)
        if server_in == 'pelisgratis':
            var_sources = pelisgratis.Pelisgratis(titulo_peli_in)
        if server_in == 'fullpeliculashd':
            var_sources = fullpeliculashd.Fullpeliculashd(titulo_peli_in)
        if server_in == 'entrepeliculasyseries':
            var_sources = entrepeliculasyseries.Entrepeliculasyseries(titulo_peli_in)
        if server_in == 'pelispedia':
            var_sources = pelispedia.Pelispedia(titulo_peli_in)
        if server_in == 'pelisplay':
            var_sources = pelisplay.Pelisplay(titulo_peli_in)
        if server_in == 'pelisencastellano':
            var_sources = pelisencastellano.Pelisencastellano(titulo_peli_in)
        if server_in == 'cliver':
            var_sources = cliver.Cliver(titulo_peli_in)
        if server_in == 'cuevana2':
            var_sources = cuevana2.Cuevana2(titulo_peli_in)
        if server_in == 'peliculasmaniac':
            var_sources = peliculasmaniac.Peliculasmaniac(titulo_peli_in)
        if server_in == 'pelis28':
            var_sources = pelis28.Pelis28(titulo_peli_in)

        sources = var_sources.get_movies()

        if len(sources) > 0:
            expiration = datetime.now() + timedelta(hours=int(my_addon.getSetting('config_cache')))
            for x in range(0, len(sources)):

                if pretty_sources(sources[x]['source']).lower() not in black_list:
                    dbcur.execute('INSERT INTO peliculas (id_peli, enlace, server, calidad, visionado, expire) VALUES("' + id_peli_in + '", "' + sources[x]['link'].replace('"','') + '", "' + sources[x]['source'] + '", "' + sources[x]['q'] + '", "0", ' + expiration.strftime("%Y%m%d%H%M%S") + ')')
                    dbcon.commit()
    except:
        pass

    dbcur.execute('UPDATE servers SET completado = "1" WHERE id_server = "' + server_in + '"')
    dbcon.commit()


mode = args.get('mode', None)

destacados = {
    'Toni', 'MiKeL', 'Jorge', 'DaQueenQueen', 'Alex303', 'Titan', 'Mixdrop', 'Directo', 'Gamovideo', 'Fembed', 'Youtube', 'Google Drive', 'Clipwatching', 'Iberika'
}

generos = [
    {'id': '28', 'genero': 'Acción'},
    {'id': '16', 'genero': 'Animación'},
    {'id': '12', 'genero': 'Aventura'},
    {'id': '10752', 'genero': 'Bélica'},
    {'id': '878', 'genero': 'Ciencia ficción'},
    {'id': '35', 'genero': 'Comedia'},
    {'id': '80', 'genero': 'Crimen'},
    {'id': '99', 'genero': 'Documental'},
    {'id': '18', 'genero': 'Drama'},
    {'id': '10751', 'genero': 'Familia'},
    {'id': '14', 'genero': 'Fantasía'},
    {'id': '36', 'genero': 'Historia'},
    {'id': '9648', 'genero': 'Misterio'},
    {'id': '10402', 'genero': 'Música'},
    {'id': '10770', 'genero': 'Película de TV'},
    {'id': '10749', 'genero': 'Romance'},
    {'id': '53', 'genero': 'Suspense'},
    {'id': '27', 'genero': 'Terror'},
    {'id': '37', 'genero': 'Western'}
]

order_q = {
    '4K':0,
    'Muy Buena':1,
    '1080':2,
    'Buena':3,
    'HD Rip':4,
    'HD':5,
    '720':6,
    '480':10,
    '360':11,
    'Screener':12,
    '270':13
}

black_list = {
    'openload',
    'streamcloud',
    'flashx',
    'filefactory',
    '1fichier',
    'myurlshort.live',
    'acortarlo.com',
    'www.videomega.co',
    'feurl.com',
    'dmca',
    'hdfull.co',
    'api.cuevana3.com',
    'videobb',
    'pelisplanet',
    'pelisplanet2'
}

servers = [
    'cliver',
    'entrepeliculasyseries', 
    'dixmax', 
    'cineonline', 
    'estrenosflix',
    'fullpeliculashd', 
    'pelisplanet', 
    'pelispedia',
    'verpelisonline', 
    'pelisencastellano', 
    'pepecine', 
    'pelisplusgo', 
    'verpeliculasultra',
    'pelisgratis', 
    'gnulapro',
    'extra',
    'pelisplay',
    'cuevana2',
    'peliculasgolden',
    'peliculasmaniac',
    'pelis28'
]

if mode is None:

    f = open(PATH+'/addon.xml', "r")
    version_local = f.read().split('version="')[2].split('"')[0]
    f.close()

    version_remota = requests.get('https://pastebin.com/raw/yt9jaVE7').text.strip()

    if version_remota != version_local:
        path_addons = PATH.replace('/plugin.video.patanegrafordev', '').replace('\\plugin.video.patanegrafordev', '')

        with requests.get('https://hirayasoftware.github.io/plugin.video.patanegrafordev/plugin.video.patanegrafordev-' + version_remota + '.zip',stream=True) as r:
            r.raise_for_status()
            with open(path_addons + '/plugin.video.patanegrafordev-' + version_remota + '.zip','wb') as f:
                for chunk in r.iter_content(chunk_size=8192): 
                    if chunk:
                        f.write(chunk)
        f.close()
        
        with zipfile.ZipFile(path_addons + '/plugin.video.patanegrafordev-' + version_remota + '.zip', 'r') as zip_ref:
            zip_ref.extractall(path_addons + '/plugin.video.patanegrafordev-' + version_remota + '.zip')

        xbmc.sleep(1000)
        os.remove(path_addons + '/plugin.video.patanegrafordev-' + version_remota + '.zip')
        xbmc.executebuiltin('XBMC.Notification(%s, %s, %s, %s)' % ('ACTUALIZACIÓN', 'Addon actualizado a la version ' + version_remota, 8000, PATH + '/icon.png'))
    
    """
    if my_addon.getSetting('config_musica') == 'true':
        try:
            play_bso()
        except:
            pass
    """


    xbmcplugin.setContent(addon_handle, "list")
    xbmc.sleep(1000)
    xbmc.executebuiltin("Container.SetViewMode(55)")

    if my_addon.getSetting('config_images') == 'true':
        if os.path.isfile(PATH + '/logos/buscar.gif') == True:
            extension = 'gif'
        else:
            extension = 'png'
    url = build_url({'mode': 'buscar', 'page': '1', 'query': '-'})
    li = xbmcgui.ListItem('Buscar película', iconImage = PATH + '/logos/buscar.' + extension)
    li.setInfo(type="Video", infoLabels={'plot': 'Buscador de películas'})
    li.setArt({'fanart': PATH + '/fanart.jpg'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    for genero in generos:
        if my_addon.getSetting('config_images') == 'true':
            if os.path.isfile(PATH + '/logos/' + genero['id'] + '.gif') == True:
                extension = 'gif'
            else:
                extension = 'png'
        url = build_url({'mode': 'pelis', 'id_genero': genero['id'], 'genero': genero['genero'], 'page': '1'})
        li = xbmcgui.ListItem(genero['genero'], iconImage = PATH + '/logos/' + genero['id'] + '.' + extension)
        li.setInfo(type="Video", infoLabels={'plot': genero['genero']})
        li.setArt({'fanart': PATH + '/fanart.jpg'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'buscar':

    pelicula = ''

    if args['query'][0] == '-':
        kb = xbmc.Keyboard('default', 'heading')
        kb.setDefault('')
        kb.setHeading('Buscar película:')
        kb.setHiddenInput(False)
        kb.doModal()
        if (kb.isConfirmed()):
            pelicula = kb.getText()
    else:
        pelicula = args['query'][0]

    if pelicula != '':

        xbmcplugin.setContent(int(sys.argv[1]), "movies")
        xbmc.sleep(1000)
        xbmc.executebuiltin("Container.SetViewMode(" + view(int(my_addon.getSetting('config_vista'))) + ")")

        xbmcplugin.setContent(int(sys.argv[1]), "movies")
        xbmc.sleep(1000)
        xbmc.executebuiltin("Container.SetViewMode(" + view(int(my_addon.getSetting('config_vista'))) + ")")

        playing_song = 0

        config_paginado = int(my_addon.getSetting('config_paginado')) + 1

        page_ini = int(args['page'][0])
        page_fin = page_ini + config_paginado

        if my_addon.getSetting('config_images') == 'true':
            check_poster_dir()
            gifs_data = requests.get('https://pastebin.com/raw/2E8sxa7A').text

        for x in range(page_ini, page_fin):

            data = tmdb_query('https://api.themoviedb.org/3/search/movie?api_key=cb123e258bbea798473fbff14e3ab87d&query=' + urllib.quote(pelicula) + '&language=es&include_adult=false&primary_release_year=0&region=ES&page=' + str(x))
            data_eng = tmdb_query('https://api.themoviedb.org/3/search/movie?api_key=cb123e258bbea798473fbff14e3ab87d&query=' + urllib.quote(pelicula) + '&language=en&include_adult=false&primary_release_year=0&region=ES&page=' + str(x))

            if my_addon.getSetting('config_musica') == 'true':
                if playing_song == 0:
                    try:
                        playing_song = play_this_song_yt(data_eng['results'][0]['title'], data['results'][0]['title'])
                    except:
                        pass

            for x in range(0, len(data['results'])):

                image = PATH + '/logos/noposter.png'
                icon = PATH + '/icon.png'
                fanart = PATH + '/fanart.jpg'

                id_peli = data['results'][x]['id']

                peli = data['results'][x]['title']
                orig_peli = data_eng['results'][x]['title']


                if my_addon.getSetting('config_images') == 'true':

                    if os.path.isfile(posters_location + '/' + str(id_peli) + '.gif') == True:
                        image = posters_location + '/' + str(id_peli) + '.gif'
                        if data['results'][x]['poster_path']  is not None:
                            icon = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['poster_path']
                    else:

                        if '#' + str(id_peli) + ':' not in gifs_data:
                            if data['results'][x]['poster_path']  is not None:
                                image = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['poster_path']
                                icon = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['poster_path']
                        else:

                            try:
                                gif = gifs_data.split('#' + str(id_peli) + ':')[1].split("\n")[0].strip()

                                with requests.get(gif,stream=True) as r:
                                    r.raise_for_status()
                                    with open(posters_location + '/' + str(id_peli) + '.gif','wb') as f:
                                        for O00x000000000O000 in r.iter_content(chunk_size=8192): 
                                            if O00x000000000O000:
                                                f.write(O00x000000000O000)
                                f.close()
                            
                                image = posters_location + '/' + str(id_peli) + '.gif'
                            except:
                                if data['results'][x]['poster_path']  is not None:
                                    image = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['poster_path']

                            if data['results'][x]['poster_path']  is not None:
                                icon = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['poster_path']

                else:
                    if data['results'][x]['poster_path']  is not None:
                        image = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['poster_path']
                        icon = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['poster_path']

                if data['results'][x]['backdrop_path']  is not None:
                    fanart = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['backdrop_path']
                elif data['results'][x]['poster_path']  is not None:
                    fanart = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['poster_path']
                else:
                    fanart = PATH + '/fanart.jpg'

                if data['results'][x]['overview'] != '':
                    overview = data['results'][x]['overview']
                else:
                    overview = peli

                url = build_url({'mode': 'sources_peli', 'orig_peli': orig_peli, 'peli': peli, 'image': icon, 'fanart': fanart, 'overview': overview, 'id_peli': id_peli})
                li = xbmcgui.ListItem(peli, iconImage = image)
                li.setInfo(type="Video", infoLabels={'plot': overview})
                li.setArt({'fanart': fanart, 'poster': image})
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

        if int(data['total_pages']) >= page_fin:
            url = build_url({'mode': 'buscar', 'page': str(int(args['page'][0])+1), 'query': pelicula})
            li = xbmcgui.ListItem('[I]Siguiente Página[/I]', iconImage = PATH + '/logos/next2.png')
            li.setInfo(type="Video", infoLabels={'plot': "[I]Siguiente Página[/I]\n\n" + pelicula})
            li.setArt({'fanart': PATH + '/fanart.jpg', 'poster': PATH + '/logos/next2.png'})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

        xbmcplugin.setContent(int(sys.argv[1]), "movies")
        xbmc.sleep(500)
        xbmc.executebuiltin("Container.SetViewMode(" + view(int(my_addon.getSetting('config_vista'))) + ")")

        xbmcplugin.setContent(int(sys.argv[1]), "movies")
        xbmc.sleep(500)
        xbmc.executebuiltin("Container.SetViewMode(" + view(int(my_addon.getSetting('config_vista'))) + ")")

        xbmcplugin.endOfDirectory(addon_handle)

        xbmcplugin.setContent(int(sys.argv[1]), "movies")
        xbmc.sleep(500)
        xbmc.executebuiltin("Container.SetViewMode(" + view(int(my_addon.getSetting('config_vista'))) + ")")

        xbmcplugin.setContent(int(sys.argv[1]), "movies")
        xbmc.sleep(500)
        xbmc.executebuiltin("Container.SetViewMode(" + view(int(my_addon.getSetting('config_vista'))) + ")")

    else:
        xbmc.executebuiltin('XBMC.Notification(%s, %s, %s, %s)' % ('UPS...', 'Debes introducir un título', 4000, PATH + '/icon.png'))

elif mode[0] == 'pelis':

    xbmcplugin.setContent(int(sys.argv[1]), "movies")
    xbmc.sleep(500)
    xbmc.executebuiltin("Container.SetViewMode(" + view(int(my_addon.getSetting('config_vista'))) + ")")

    xbmcplugin.setContent(int(sys.argv[1]), "movies")
    xbmc.sleep(500)
    xbmc.executebuiltin("Container.SetViewMode(" + view(int(my_addon.getSetting('config_vista'))) + ")")

    playing_song = 0

    config_paginado = int(my_addon.getSetting('config_paginado')) + 1

    page_ini = int(args['page'][0])
    page_fin = page_ini + config_paginado

    if my_addon.getSetting('config_images') == 'true':
        check_poster_dir()
        gifs_data = requests.get('https://pastebin.com/raw/2E8sxa7A').text

    for x in range(page_ini, page_fin):

        data = tmdb_query('https://api.themoviedb.org/3/discover/movie?api_key=cb123e258bbea798473fbff14e3ab87d&language=es&media_type=movie&vote_average.gte=0&sort_by=primary_release_date.desc&include_adult=false&primary_release_year=0&primary_release_date.lte=' + datetime.now().strftime("%Y-%m-%d") + '&primary_release_date.gte=1000-01-01&region=ES&page=' + str(x) + '&with_genres=' + args['id_genero'][0])
        data_eng = tmdb_query('https://api.themoviedb.org/3/discover/movie?api_key=cb123e258bbea798473fbff14e3ab87d&language=en&media_type=movie&vote_average.gte=0&sort_by=primary_release_date.desc&include_adult=false&primary_release_year=0&primary_release_date.lte=' + datetime.now().strftime("%Y-%m-%d") + '&primary_release_date.gte=1000-01-01&region=ES&page=' + str(x) + '&with_genres=' + args['id_genero'][0])

        if my_addon.getSetting('config_musica') == 'true':
            if playing_song == 0 or xbmc.Player().isPlaying() == False:
                rn = random.randint(0,len(data_eng['results'])-1)
                playing_song = play_this_song_yt(data_eng['results'][rn]['title'], data['results'][rn]['title'])

        for x in range(0, len(data['results'])):

            image = PATH + '/logos/noposter.png'
            icon = PATH + '/icon.png'
            fanart = PATH + '/fanart.jpg'

            id_peli = data['results'][x]['id']

            peli = data['results'][x]['title']

            orig_peli = data_eng['results'][x]['title']

            if my_addon.getSetting('config_images') == 'true':

                if os.path.isfile(posters_location + '/' + str(id_peli) + '.gif') == True:
                    image = posters_location + '/' + str(id_peli) + '.gif'
                    if data['results'][x]['poster_path']  is not None:
                        icon = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['poster_path']
                else:

                    if '#' + str(id_peli) + ':' not in gifs_data:
                        if data['results'][x]['poster_path']  is not None:
                            image = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['poster_path']
                            icon = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['poster_path']
                    else:
                        try:
                            gif = gifs_data.split('#' + str(id_peli) + ':')[1].split("\n")[0].strip()

                            with requests.get(gif,stream=True) as r:
                                r.raise_for_status()
                                with open(posters_location + '/' + str(id_peli) + '.gif','wb') as f:
                                    for O00x000000000O000 in r.iter_content(chunk_size=8192): 
                                        if O00x000000000O000:
                                            f.write(O00x000000000O000)
                            f.close()
                        
                            image = posters_location + '/' + str(id_peli) + '.gif'
                        except:
                            if data['results'][x]['poster_path']  is not None:
                                image = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['poster_path']

                        if data['results'][x]['poster_path']  is not None:
                            icon = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['poster_path']
            else:
                if data['results'][x]['poster_path']  is not None:
                    image = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['poster_path']
                    icon = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['poster_path']
            
            if data['results'][x]['backdrop_path']  is not None:
                fanart = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['backdrop_path']
            elif data['results'][x]['poster_path']  is not None:
                fanart = 'https://image.tmdb.org/t/p/w500/' + data['results'][x]['poster_path']
            else:
                fanart = ''

            if data['results'][x]['overview'] != '':
                overview = data['results'][x]['overview']
            else:
                overview = peli

            url = build_url({'mode': 'sources_peli', 'orig_peli': orig_peli, 'peli': peli, 'image': icon, 'fanart': fanart, 'overview': overview, 'id_peli': id_peli})
            li = xbmcgui.ListItem(peli, iconImage = icon)
            li.setInfo(type="Video", infoLabels={'plot': overview})
            li.setArt({'fanart': fanart, 'poster': image})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    if int(data['total_pages']) >= page_fin:
        url = build_url({'mode': 'pelis', 'id_genero': args['id_genero'][0], 'genero': args['genero'][0], 'page': str(page_fin)})
        li = xbmcgui.ListItem('[I]Siguiente Página[/I]', iconImage = PATH + '/logos/next2.png')
        li.setArt({'fanart': PATH + '/fanart.jpg', 'poster': PATH + '/logos/next2.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.setContent(int(sys.argv[1]), "movies")
    xbmc.sleep(500)
    xbmc.executebuiltin("Container.SetViewMode(" + view(int(my_addon.getSetting('config_vista'))) + ")")

    xbmcplugin.setContent(int(sys.argv[1]), "movies")
    xbmc.sleep(500)
    xbmc.executebuiltin("Container.SetViewMode(" + view(int(my_addon.getSetting('config_vista'))) + ")")
    
    xbmcplugin.endOfDirectory(addon_handle)

    xbmcplugin.setContent(int(sys.argv[1]), "movies")
    xbmc.sleep(500)
    xbmc.executebuiltin("Container.SetViewMode(" + view(int(my_addon.getSetting('config_vista'))) + ")")

    xbmcplugin.setContent(int(sys.argv[1]), "movies")
    xbmc.sleep(500)
    xbmc.executebuiltin("Container.SetViewMode(" + view(int(my_addon.getSetting('config_vista'))) + ")")

elif mode[0] == 'sources_peli':

    if my_addon.getSetting('config_musica') == 'true':
        play_this_song_yt(args['orig_peli'][0], args['peli'][0])

    total_sources = []

    guarda = 0

    dbcur.execute("CREATE TABLE IF NOT EXISTS servers (id_server TEXT, completado TEXT, UNIQUE(id_server));")
    dbcon.commit()

    dbcur.execute("CREATE TABLE IF NOT EXISTS peliculas (id_enlace INTEGER PRIMARY KEY AUTOINCREMENT, id_peli TEXT, enlace TEXT, server TEXT, calidad TEXT, visionado TEXT, expire INT)")
    dbcon.commit()

    dbcur.execute("DELETE FROM peliculas WHERE expire < " + datetime.now().strftime("%Y%m%d%H%M%S"))








    dbcur.execute('SELECT * FROM peliculas WHERE id_peli = "' + args['id_peli'][0] + '" AND expire > ' + datetime.now().strftime("%Y%m%d%H%M%S") + ' ORDER BY id_enlace ASC')
    matches = dbcur.fetchall()

    if len(matches) == 0:

        progreso = xbmcgui.DialogProgressBG()
        progreso.create("BUSCANDO FUENTES", "Fuentes encontradas: 0")
        porcentaje = 1

        dbcur.execute("DELETE FROM servers")
        dbcon.commit()

        for x in range(0, len(servers)):

            dbcur.execute('INSERT INTO servers VALUES("' + servers[x] + '", "0")')
            dbcon.commit()

            t = Thread(target=get_sources_from, args=[servers[x], args['id_peli'][0], args['peli'][0]])
            t.setDaemon(True)
            t.start()

        while True:

            dbcur.execute('SELECT COUNT(*) FROM servers WHERE completado = "1"')
            match_servers = dbcur.fetchone()

            if match_servers != None:

                dbcur.execute('SELECT COUNT(*) FROM peliculas WHERE id_peli = "' + args['id_peli'][0] + '"')
                match_peliculas = dbcur.fetchone()
                progreso.update(int(100/len(servers)) * int(match_servers[0]), "BUSCANDO FUENTES", "Fuentes encontradas: %s" % match_peliculas[0])
                xbmc.sleep(2000)

                if int(match_servers[0]) == len(servers):
                    break

        guarda = 1

        dbcur.execute('SELECT * FROM peliculas WHERE id_peli = "' + args['id_peli'][0] + '" ORDER BY id_enlace ASC')
        matches = dbcur.fetchall()








    for x in range(0, len(matches)):

        match = list(matches[x])

        if '?' in match[4]:
            match[4] = 'Buena'

        elif 'TS' in match[4] or 'CAM' in match[4] or 'screener' in match[4] or 'Cam' in match[4] or 'poor' in match[4]:
            match[4] = 'Screener'

        elif 'HDRIP' in match[4] or 'rip' in match[4] or 'HDTV' in match[4] or 'HDRip' in match[4] or '1080' in match[4] or 'high' in match[4] or 'DVD' in match[4] or 'BR' in match[4] or 'Blu' in match[4] or 'BLu' in match[4] or 'Dvd' in match[4]:
            match[4] = '1080'

        elif '720' in match[4] or 'medium' in match[4]:
            match[4] = '720'

        elif '480' in match[4] or 'low' in match[4]:
            match[4] = '480'

        elif '360' in match[4]:
            match[4] = '360'

        elif '270' in match[4]:
            match[4] = '270'

        elif '240' in match[4]:
            match[4] = '240'

        elif '4K' in match[4]:
            match[4] = '4K'

        else:
            match[4] = 'Buena'

        match.append(order_q[match[4].replace('&amp;', '&')])
        total_sources.append(match)

    total_sources = sorted(total_sources, key = lambda i: i[7],reverse=False)

    dbcur.execute("CREATE TABLE IF NOT EXISTS pelis_sources (sources TEXT);")
    dbcon.commit()

    dbcur.execute("DELETE FROM pelis_sources")
    dbcon.commit()

    data = tmdb_query('https://api.themoviedb.org/3/movie/' + args['id_peli'][0] + '?api_key=cb123e258bbea798473fbff14e3ab87d&language=es')

    nnn = 0

    db_sources = []

    for x in range(0, len(total_sources)):

        if total_sources[x][2] != '':

            db_sources.append(total_sources[nnn])

            url = build_url({
                'mode': 'play_this', 
                'id_peli': args['id_peli'][0],  
                'peli': args['peli'][0], 
                'image': args['image'][0], 
                'fanart': args['fanart'][0], 
                'overview': args['overview'][0], 
                'link': total_sources[x][2], 
                'source': pretty_sources(total_sources[x][3]),
                'n': nnn
            })
            
            nnn = nnn + 1

            if pretty_sources(total_sources[x][3]) in destacados:
                li = xbmcgui.ListItem('[COLOR orange]' + three_char_num(str(x+1)) + ' | [B]' + args['peli'][0] + '[/B] | ' + total_sources[x][4].replace('&amp;', '&') + ' | [I]' + pretty_sources(total_sources[x][3]) + '[/I][/COLOR]', iconImage = args['image'][0])
            else:
                li = xbmcgui.ListItem(three_char_num(str(x+1)) + ' | [B]' + args['peli'][0] + '[/B] | ' + total_sources[x][4].replace('&amp;', '&') + ' | [I]' + pretty_sources(total_sources[x][3]) + '[/I]', iconImage = args['image'][0])
            li.setInfo(type="Video", infoLabels={'plot': args['peli'][0] + "\n\n" + args['overview'][0], "Duration" : int(data['runtime']) * 60})
            li.setArt({'fanart': args['fanart'][0]})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    dbcur.execute('INSERT INTO pelis_sources VALUES("' + base64.b64encode(json.dumps(total_sources)) + '")')
    dbcon.commit()

    xbmcplugin.endOfDirectory(addon_handle)

    xbmcplugin.setContent(int(sys.argv[1]), "list")
    xbmc.sleep(1000)
    xbmc.executebuiltin("Container.SetViewMode(55)")

    xbmcplugin.setContent(int(sys.argv[1]), "list")
    xbmc.sleep(1000)
    xbmc.executebuiltin("Container.SetViewMode(55)")

    try:
        progreso.close()
    except:
        pass

elif mode[0] == 'play_this':
    stream_url = ''

    listitem = xbmcgui.ListItem(args['peli'][0])
    listitem.setInfo(type="Video", infoLabels={
        'plot': args['peli'][0] + "\n\n" + args['overview'][0],
        'Title' : '[B]' + args['peli'][0] + '[/B]'
    })
    listitem.setArt({ 'poster': args['image'][0], 'fanart': args['fanart'][0] })

    peli_num = int(args['n'][0])

    dbcur.execute("SELECT sources FROM pelis_sources")

    match = dbcur.fetchone()

    total_sources = json.loads(base64.b64decode(match[0]))

    DIALOG_PROGRESS = xbmcgui.DialogProgress()
    DIALOG_PROGRESS.create("Probando Enlaces", "")
    WINDOW_PROGRESS = xbmcgui.Window(10101)
    xbmc.sleep(100)
    CANCEL_BUTTON = WINDOW_PROGRESS.getControl(10)

    last_x = 0

    playing_some_time = 0

    for x in range(peli_num, len(total_sources)):

        if DIALOG_PROGRESS.iscanceled():
            DIALOG_PROGRESS.close()
            up_vol()
            break

        xbmc.sleep(500)
        DIALOG_PROGRESS.update(int((x+1)*100/len(total_sources)), three_char_num(str(x+1)) + " | [B]" + args['peli'][0] + "[/B] | " + total_sources[x][4].replace('&amp;', '&') + " | [I]" + pretty_sources(total_sources[x][3]) + "[/I]")

        if total_sources[x][3] == 'Alex303' or total_sources[x][3] == 'DaQueenQueen' or total_sources[x][3] == 'MiKeL' or total_sources[x][3] == 'Toni' or total_sources[x][3] == 'Jorge' or total_sources[x][3] == 'Iberika' or total_sources[x][3] == 'Titan':
            if 'gamovideo' not in total_sources[x][2] and 'mixdrop' not in total_sources[x][2] and 'drive.google' not in total_sources[x][2]:
                total_sources[x][3] = 'directo'

        if total_sources[x][3] == 'Google Drive' or total_sources[x][3] == 'directo':
            
            kill_vol()
            xbmc.Player().play(total_sources[x][2] + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; WOW64; rv:56.0) Gecko/20100101 Firefox/56.0', listitem)
            
            for y in range(1, 9):
                xbmc.sleep(1000)
                if xbmc.Player().isPlaying():
                    tiempo = xbmc.Player().getTime()
                    if str(tiempo) != '0.0':
                        playing_some_time = 1
                        break

            if playing_some_time == 1:
                DIALOG_PROGRESS.close()
                up_vol()
                break

        elif pretty_sources(total_sources[x][3]) == 'Clipwatching':
            try:
                request_headers=[]
                request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
                body,response_headers = plugintools.read_body_and_headers( total_sources[x][2], headers=request_headers)
                body2,response_headers2 = plugintools.read_body_and_headers( total_sources[x][2], headers=request_headers)
                video = plugintools.find_single_match(body2.strip(),'sources: ."(.*?)"')

                if video != '' and video != False and 'small3.mp4' not in video:
                    kill_vol()
                    xbmc.Player().play(video, listitem)
                    xbmc.sleep(19000)

                    for y in range(1, 19):
                        xbmc.sleep(1000)
                        if xbmc.Player().isPlaying():
                            tiempo = xbmc.Player().getTime()
                            if str(tiempo) != '0.0':
                                playing_some_time = 1
                                break

                    if playing_some_time == 1:
                        DIALOG_PROGRESS.close()
                        up_vol()
                        break
            except:
                pass


        elif total_sources[x][3] == 'Gamovideo':

            ua = 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36'
            url=total_sources[x][2]
            s=requests.session()
            rsource=s.get(url, headers={'User-Agent': ua},  verify=False)
            source=s.get(url, headers={'User-Agent': ua},  verify=False)
            pack = re.findall('javascript.*?(eval\(function\(p,a,c,k,e,d.*)', source.text)[0]
            unpack=jsunpack.unpack(pack)
            video = re.findall('(?s)sources.*?file:\s*"(http.*?)"', unpack)[0]+'|User-Agent='+ua

            if video != '' and video != False and 'small3.mp4' not in video:
                kill_vol()
                xbmc.Player().play(video, listitem)
                xbmc.sleep(19000)

                for y in range(1, 19):
                    xbmc.sleep(1000)
                    if xbmc.Player().isPlaying():
                        tiempo = xbmc.Player().getTime()
                        if str(tiempo) != '0.0':
                            playing_some_time = 1
                            break

                if playing_some_time == 1:
                    DIALOG_PROGRESS.close()
                    up_vol()
                    break

        else:

            if total_sources[x][3] == 'Fembed':
                total_sources[x][2] = total_sources[x][2].replace('/f/', '/v/').replace('https://www.ilovefembed.best', 'https://www.fembed.com')

            if total_sources[x][3] == 'Streamplay':
                total_sources[x][2] = total_sources[x][2].replace('streamp1ay.me', 'streamplay.to')

            try:
                stream_url = urlresolver.resolve(total_sources[x][2])
            except:
                pass

            if stream_url == '' or stream_url == False:
                try:
                    stream_url = resolveurl.resolve(total_sources[x][2])
                except:
                    pass

            if stream_url != '' and stream_url != False and 'small3.mp4' not in stream_url:
                kill_vol()
                xbmc.Player().play(stream_url, listitem)
                xbmc.sleep(19000)

                for y in range(1, 19):
                    xbmc.sleep(1000)
                    if xbmc.Player().isPlaying():
                        tiempo = xbmc.Player().getTime()
                        if str(tiempo) != '0.0':
                            playing_some_time = 1
                            break

                if playing_some_time == 1:
                    DIALOG_PROGRESS.close()
                    up_vol()
                    break

        if my_addon.getSetting('config_autoplay') == 'false':
            break
    DIALOG_PROGRESS.close()