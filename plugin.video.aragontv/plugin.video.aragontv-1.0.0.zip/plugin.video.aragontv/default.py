#encoding=utf-8
import sys
import xbmcgui
import xbmcplugin
import xbmc
import urllib
import urllib2
import urlparse
import xbmcaddon
import os
import unicodedata
import plugintools
from HTMLParser import HTMLParser
from types import UnicodeType
 
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
my_addon = xbmcaddon.Addon()
PATH = my_addon.getAddonInfo('path')
sys.path.append(xbmc.translatePath(os.path.join(PATH, 'lib')))

channellist = [
    [
        "user/aragontelevision",
        "https://yt3.ggpht.com/a/AGF-l786QRAnQGEOwRsUQjnB2A-7vke-Qsb9KMRBYA=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Aragon TV"
    ],[
        "channel/UCYQyHNOvhC_BS7K9UCThIsg",
        "https://yt3.ggpht.com/a/AGF-l7_G2CsTxODvCF1ov6dvLwsYQROuS4ABGJ-rpA=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Aragón Deporte"
    ],[
        "channel/UCGrko-d0NCXlXxXPCEPEX4A",
        "https://yt3.ggpht.com/a/AGF-l7_jA3s97ljWn-gMwKMLFMkTJKaFwW7FClJNDg=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Aragon en abierto"
    ],[
        "channel/UCz9ZgM9oEEvlpAQGUAN7NuA",
        "https://yt3.ggpht.com/a/AGF-l7-c0wUO4QrctjuRcBkRK8oHdtHYyGhnmwzG5w=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Aragon Noticias"
    ],[
        "channel/UCACFlIMDawwTIU0V1lCqsJQ",
        "https://yt3.ggpht.com/a/AGF-l78fb1ygmwK9260b7YRzao1R_v_TvAJlTdZjCw=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Bien Dicho"
    ],[
        "channel/UCJMvr-dowiuZqn0Q-9pVyGQ",
        "https://yt3.ggpht.com/a/AGF-l7_uPlCcsWISUv-P1wmme2u_xk6QuNbikNIoxQ=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Camino al empleo"
    ],[
        "channel/UC3yYFebMFORhesrYbKLawRQ",
        "https://yt3.ggpht.com/a/AGF-l78_nVhV3m7SljXfixnYqiwRuaIS4RMaeO0ZAA=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - El Avispero"
    ],[
        "channel/UCbmqhBatTD5EZkKNvrXLY7g",
        "https://yt3.ggpht.com/a/AGF-l7-SzeR1AVpBmkEoQbM3NTVC36CHBHdW5hiqsA=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - En ruta con la ciencia"
    ],[
        "channel/UCcnOBy80GS942in0Sb7o9vQ",
        "https://yt3.ggpht.com/a/AGF-l7_BhoXCcZBUqjTTPMGfmdHEb7vdt_vdZPkq5Q=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Entrevista con"
    ],[
        "channel/UCP0RUVaYhnB3RIsKXdr9s8w",
        "https://yt3.ggpht.com/a/AGF-l7_2QcTiLKKLq2iQ9l46pQfizVhcpYRc84_QTQ=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - La Báscula"
    ],[
        "channel/UC5NR7mxmsvvPy1mg-1BQo4g",
        "https://yt3.ggpht.com/a/AGF-l7_a-37VwVVQpQAGy8m1QDwGGnt3TzNp3sw9TQ=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - La Jornada"
    ],[
        "channel/UCFipzUfgn0IyV9qKwMnjbng",
        "https://yt3.ggpht.com/a/AGF-l79LQ7W4ht-BTplR_Vi9fN0s2K5Af71Alqbnmg=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - La Madriguera"
    ],[
        "channel/UCfFdSYWdgpF2L4TK0P_OnSg",
        "https://yt3.ggpht.com/a/AGF-l7_3JsSgpDyGxx3l1QxioJ7mGqKvqj0mj1GH4A=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - La Pera Limonera"
    ],[
        "channel/UCSwPQoXOkG8yiQn6e3qhDjQ",
        "https://yt3.ggpht.com/a/AGF-l79tJ3ayXRqiJyJUCBF77zlcV4BIrzffZhPRtQ=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Motormania Atv"
    ],[
        "channel/UCERHDCHGq_O2VZbxIC63yDA",
        "https://yt3.ggpht.com/a/AGF-l7_OKog3M5OpbILF2Tdn2MRxomADgrTpRHH87g=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Por amor al arte"
    ],[
        "channel/UC6PFY0qKE7Po2u3oQD1LuEg",
        "https://yt3.ggpht.com/a/AGF-l79I-TZJILQSvuFo3HdY53HL4R03a4LDq2Ujlw=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Reino y Corona"
    ],[
        "channel/UCtGgvqsKEPYRI0YLrqYG8cw",
        "https://yt3.ggpht.com/a/AGF-l7-Hpj5g6uIEx1i6GxH9K9d22KOsHxXGTjJDxg=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Tempero Aragon TV"
    ],[
        "channel/UCc_hKW1lRVAo7XWtiSN1ntA",
        "https://yt3.ggpht.com/a/AGF-l7967FW1sY7oHW7jsaoNrncDOIdjcikewpHiGA=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Unidad Móvil Aragón TV"
    ],[
        "channel/UCPzdzAXjLHGM1I4MVbTJqJw",
        "https://yt3.ggpht.com/a/AGF-l78bII4m8JUSAXKBwMV27G9cEHkivh82CafmGg=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Objetivo Aragón TV"
    ],[
        "channel/UCFWXMR83g42h4IrnXw0LK7A",
        "https://yt3.ggpht.com/a/AGF-l7-LjsVTwm5lcqEsUsBtsZhrihL8l1NE-Qlr0w=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Segunda Oportunidad"
    ],[
        "channel/UC9Tm7F0rMYIUw4U5GefdltQ",
        "https://yt3.ggpht.com/a/AGF-l78XrFQBKEiqv8L3Hp80I-VM_03k7AB06sWVIg=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Te suena?"
    ],[
        "channel/UCLa1rRbgYFBUiQqp2oi3kYA",
        "https://yt3.ggpht.com/a/AGF-l7_JHXZv7sRoqIEkY6xqXVMYduFrX-oHGiZjUg=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - X La Cara"
    ],[
        "channel/UCQU1dRQStEtW7Yjp1ClCFxA",
        "https://yt3.ggpht.com/a/AGF-l7-PyxXUMDOLAVFrXMP17on0BZiZNKHAxHyWZQ=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Zarrios ATV"
    ],[
        "channel/UC-wg0gzf5rP6J6YURGM16OA",
        "https://yt3.ggpht.com/a/AGF-l7_8IgjLuPL5r8cxlWqiTA--CJViYa3wxfH1WQ=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Ficción Aragón TV"
    ],[
        "channel/UCjsXSviBMoA79VNC0MdGn5Q",
        "https://yt3.ggpht.com/a/AGF-l79RKjWV4k5Ke_rPTQ-53LCL3_P0t6saGpMrRQ=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Chino Chano Aragón TV"
    ],[
        "channel/UCBPPuvxLFoaYHNelzueuWDg",
        "https://yt3.ggpht.com/a/AGF-l79NnTQwdM9wIL-q06OrtHd118_ATxeEiSP6iw=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Dándolo Todo Jota Aragón TV"
    ],[
        "channel/UC6himNRWb1L7dghEw0lpB_Q",
        "https://yt3.ggpht.com/a/AGF-l79PaYEufdpy9adDxWEd-cm6OGZ2U45csDm3cw=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Run Aragón TV"
    ],[
        "channel/UCTtwwHIx58osH5Vt6bXRp_w",
        "https://yt3.ggpht.com/a/AGF-l7-fEPsHcXbxxrz_Yf1n30V1swgmJTpkyYhkEg=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Sin ir más lejos Aragón TV"
    ],[
        "channel/UCPQ4MM8EDFZCA159Qe8ZDQw",
        "https://yt3.ggpht.com/a/AGF-l7894x3Lb82cw_6EuPg38y9Sle5_W_HtMbLwUA=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Aftersun Aragón TV"
    ],[
        "channel/UCJL70ZLrYZ3Lh0U-FBCr4Gw",
        "https://yt3.ggpht.com/a/AGF-l7_pyeIZFLjB3HyJrdEqeCsxyN6OcJVnMyg3ww=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Rural Chef Aragón TV"
    ],[
        "channel/UCyHMkSTOxop8cf781k1x-sA",
        "https://yt3.ggpht.com/a/AGF-l7_zFMlq7tUt4QmB7Oh1Z4QSOWA5rrhe6-VQSQ=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - MadeInAragon"
    ],[
        "channel/UCuxZUiy4uY4L9a-M1dQP1uA",
        "https://yt3.ggpht.com/a/AGF-l7-3lFnAtiUpZFg0LkgsTO8SobByA32YQpXO7Q=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Comedyantes Aragón TV"
    ],[
        "channel/UCRH7p2j29pSsrcLJ6ZNHqEg",
        "https://yt3.ggpht.com/a/AGF-l7__CmS-8BIX5Fi3snu5lC-GjCVvFNSUGHABxA=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - La batalla de las tapas Aragón TV"
    ],[
        "channel/UCr0VHWw0VUFBnwoIQiu4rLQ",
        "https://yt3.ggpht.com/a/AGF-l7_KlohhG-jOW12FLlnXOl4gZXpxROrm48ELGw=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - La alfombra roja Aragón TV"
    ],[
        "channel/UCS3MfB6wtJn5krielEg9Fmw",
        "https://yt3.ggpht.com/a/AGF-l7-mVbCv8fpUQt-zwdnOSJONMmyzz1vga6M0BQ=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Deratonesyvinilos Aragón TV"
    ],[
        "channel/UCCasL1RdMTyQWqBmActUxQA",
        "https://yt3.ggpht.com/a/AGF-l79tm8fpDA1X6UB4TiyfDnn2RwlZdOLabGcPRA=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Oregón TV Aragón TV"
    ],[
        "channel/UChh3Dj7GH8NTF5hCnanapiQ",
        "https://yt3.ggpht.com/a/AGF-l792N9fKk4MZwk0YKxxDG3fltf-H04UNi34DwQ=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Otro punto de vista Aragón TV"
    ],[
        "channel/UC2dMkPg29mV-JZqWJC06cXg",
        "https://yt3.ggpht.com/a/AGF-l7_LZ1CcoYaktoplnX7lZVa3xfbaBAFuH8vFNg=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Lo tuyo es puro teatro ATV"
    ],[
        "channel/UC3sENmiHiaUtMeGyBZxaoKw",
        "https://yt3.ggpht.com/a/AGF-l7-KV2kqqFLLUxmvlB5OfIFiS8YQ6zKdZ3Gp-A=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Vuelta atrás Aragón TV"
    ],[
        "channel/UCPiA_nbnjisEWyxIjvYgcjw",
        "https://yt3.ggpht.com/a/AGF-l78IgIPSmpScOPwe1UE4icL1UgP9k9tWLdun=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Charrín Charrán Aragón TV"
    ],[
        "channel/UCA2d0VJN_h-vqqRdA0ulqew",
        "https://yt3.ggpht.com/a/AGF-l7-GVYCFdBp3QSZDx_2nFsUBMNRpiK4_yyqMIw=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Equipo de guardia Aragón TV"
    ],[
        "channel/UC30BkqL2BXxxYDC0hII5IpA",
        "https://yt3.ggpht.com/a/AGF-l7-TubbKliEUe5adB3pc5VAymWTuzYNfcMYfnA=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Atrapame si puedes Aragón TV"
    ],[
        "channel/UCV90wh9w2NTUPg6S_gS02rQ",
        "https://yt3.ggpht.com/a/AGF-l7_JVI97OUK-Ql3MXMKH2J-wMdAJ5ySGUrCq_w=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Cosas de clase Aragón TV"
    ],[
        "channel/UCSQvgwKjPIuoWJHha52buHg",
        "https://yt3.ggpht.com/a/AGF-l7-2vGMlVh_FNEngseHqc0GN_pbE_BKFoLtCqg=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Seguimos Aragon TV"
    ],[
        "channel/UC0xaPYOa5Bx0KHXrNRmY4_w",
        "https://yt3.ggpht.com/a/AGF-l7_JEvX1UAd6fAytxwt3mlktjQQsC4QsgUV5qw=s288-c-k-c0xffffffff-no-rj-mo",
        "YouTube - Comunidad Sonora Aragón TV"
    ]
]

def utf8me(string_in):
    return safe_unicode(string_in).encode('utf-8')

def safe_unicode(value):
    if type(value) is UnicodeType:
        return value
    else:
        try:
            return unicode(value, 'utf-8')
        except:
            return unicode(value, 'iso-8859-1')
 
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def decode_html(value):
    try:
        unicode_title = unicode(value, "utf8", "ignore")
        return utf8me(HTMLParser().unescape(unicode_title).encode("utf8"))
    except:
        return utf8me(value)

def browse_this_shit(url_in):
    try:
        request = urllib2.Request(url_in)
        return urllib2.urlopen(request).read()
    except:
        return browse_this_shit(url_in)

def time_to_seconds(time_in):
    a = time_in.split(':')
    if len(a) > 1:
        if len(a) == 2:
            return (int(a[0])*60) + int(a[1])
        else:
            return (int(a[0])*60*60) + (int(a[1])*60) + int(a[2])
    else:
        return ''

mode = args.get('mode', None)

if mode is None:
    index_html = browse_this_shit('http://alacarta.aragontelevision.es/programas')
    a = index_html.split('<div class="bloque')
    for x in range(1, len(a)):
        b = a[x].split('src="')
        c = b[1].split('"')
        d = a[x].split('href="')
        e = d[1].split('"')
        f = a[x].split('<strong>')
        g = f[1].split('</strong>')
        h = a[x].split('<p style="float:left; width: 100%;">')
        i = h[1].split('</p>')
        url = build_url({'mode': 'indice', 'title': g[0], 'href': 'http://alacarta.aragontelevision.es' + e[0]})
        li = xbmcgui.ListItem(g[0], iconImage = 'http://alacarta.aragontelevision.es' + c[0])
        li.setInfo(type="Video", infoLabels={"plot": i[0]})
        li.setArt({'fanart': 'http://alacarta.aragontelevision.es' + c[0]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    channellist = sorted(channellist, key = lambda i: i[2],reverse=False)
    for id, icon, name in channellist:
        plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,folder=True)
    xbmcplugin.endOfDirectory(addon_handle)
    
elif mode[0] == 'indice':
    y = 0
    while True:
        y = y + 1
        show_html = browse_this_shit(args['href'][0] + 'pagina/' + str(y) + '/')
        a = show_html.split('class="vid bloque')
        if len(a) < 2:
            break
        else:
            for x in range(1, len(a)):
                b = a[x].split('<a href="')
                c = b[1].split('"')
                d = a[x].split('src="')
                e = d[1].split('"')
                f = a[x].split('rel="videoFacebox">')
                g = f[2].split('</a')
                h = a[x].split('Duración: ')
                i = h[1].split('<')
                url = build_url({'mode': 'play', 'title': decode_html(g[0]), 'href': 'http://alacarta.aragontelevision.es' + c[0]})
                li = xbmcgui.ListItem(decode_html(g[0]), iconImage = 'http://alacarta.aragontelevision.es' + e[0].replace('_thumb', ''))
                li.setInfo(type="Video", infoLabels={"plot": decode_html(g[0]), "Duration" : time_to_seconds(i[0].strip())})
                li.setArt({'fanart': 'http://alacarta.aragontelevision.es' + e[0]})
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'play':
    video_html = browse_this_shit(args['href'][0])
    a = video_html.split('<source src="')
    b = a[1].split('"')
    listitem = xbmcgui.ListItem(args['title'][0])
    listitem.setInfo('video', {'Title': args['title'][0]})
    xbmc.Player().play(b[0], listitem)