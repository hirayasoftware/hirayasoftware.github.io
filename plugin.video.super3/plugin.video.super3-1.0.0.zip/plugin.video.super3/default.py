# encoding=utf8
import sys
import xbmcgui
import xbmcplugin
import xbmc
import urllib
import urllib2
import urlparse
import xbmcaddon
import os
import re
import unicodedata
import plugintools
from HTMLParser import HTMLParser
from types import UnicodeType
 
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
my_addon = xbmcaddon.Addon()
PATH = my_addon.getAddonInfo('path')
sys.path.append(xbmc.translatePath(os.path.join(PATH, 'lib')))

channellist = [
    [
        "YouTube - Les Tres Bessones",
        "channel/UCOlOS3X6X7_R38oZuJwE6iA",
        "https://yt3.ggpht.com/a/AGF-l794iFHQKq7qpcy4Dy6nuuKpfyTX5tQkuCLWxw=s288-c-k-c0xffffffff-no-rj-mo"
    ],[
        "YouTube - Super 3",
        "channel/UCAJJ-Y7IxDDG5igW4gnXUUg",
        "https://yt3.ggpht.com/a/AGF-l78daa3zVbZS1WyCTgFqCvUBQD80Il6QWKTbJQ=s288-c-k-c0xffffffff-no-rj-mo"
    ]
]

def strip_accents(text):
    try:
        text = unicode(text.encode("utf-8"), 'utf-8')
    except NameError:
        pass
    text = unicodedata.normalize('NFD', text)\
           .encode('ascii', 'ignore')\
           .decode("utf-8")
    return str(text)

def only_legal_chars(string_in):
    string_out = re.sub(r'[#\\/:"*?<>|]+', "", string_in)
    string_out = "".join(i for i in string_out if ord(i)<128)
    string_out = ' '.join(string_out.split())
    return string_out

def utf8me(string_in):
    return safe_unicode(string_in).encode('utf-8')

def safe_unicode(value):
    if type(value) is UnicodeType:
        return value
    else:
        try:
            return unicode(value, 'utf-8')
        except:
            return unicode(value, 'iso-8859-1')
 
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def decode_html(value):
    try:
        unicode_title = unicode(value, "utf8", "ignore")
        return utf8me(HTMLParser().unescape(unicode_title).encode("utf8"))
    except:
        return utf8me(value)

def browse_this_shit(url_in):
    xbmc.log('BROWSING NA: %s' % (url_in), xbmc.LOGNOTICE)
    try:
        request = urllib2.Request(url_in)
        return urllib2.urlopen(request).read()
    except:
        url_in = url_in.replace('videos/', '').replace('/fitxa-programa', '/videos/fitxa-programa')
        return browse_this_shit(url_in)

def clean_me(string_in):
    return string_in.replace('&#039;','\'').replace('&quot;', '"').replace('&amp;','&')

mode = args.get('mode', None)

if mode is None:

    response = browse_this_shit('https://www.ccma.cat/tv3/super3/series-i-programes/')

    aa = response.split('itemContenidorIntern')

    for x in range(1, len(aa)):
        bb = aa[x].split('title="')
        cc = bb[1].split('"')

        dd = aa[x].split('href="')
        ee = dd[1].split('"')

        ff = aa[x].split('src="')
        gg = ff[1].split('"')

        url = build_url({'mode': 'show', 'title': clean_me(cc[0]), 'href': 'https://www.ccma.cat' + ee[0] + 'videos/'})
        li = xbmcgui.ListItem(clean_me(cc[0]), iconImage = 'https:' + gg[0])
        li.setInfo(type="Video", infoLabels={"plot": clean_me(cc[0])})
        li.setArt({'fanart': 'https:' + gg[0]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'musica', 'title': 'Videos Musicals'})
    li = xbmcgui.ListItem('Videos Musicals', iconImage = PATH + '/icon.png')
    li.setInfo(type="Video", infoLabels={"plot": 'Videos Musicals'})
    li.setArt({'fanart': PATH + '/fanart.jpg'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    for name, id, icon in channellist:
        plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,folder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'musica':

    pag = 1

    while True:
        response = browse_this_shit('https://www.ccma.cat/Comu/standalone/tv3_super3_musica_videos/contenidor/contenidorVideos2/' + str(pag) + '/0')

        aa = response.split('<a class="media-object"')

        if len(aa) > 1:
            for x in range(1, len(aa)):
                bb = aa[x].split('<h2')
                cc = bb[1].split('>')
                dd = cc[1].split('</h2')

                ee = aa[x].split('href="')
                ff = ee[1].split('"')
                nn = ff[0].split('/')

                gg = aa[x].split('data-src="')
                hh = gg[1].split('"')

                url = build_url({'mode': 'episode', 'title': clean_me(dd[0]), 'href': 'https://dinamics.ccma.cat/pvideo/media.jsp?media=video&versio=1&idint=' + nn[-2] + '&profile=pc&broadcast=false&format=dm'})
                li = xbmcgui.ListItem(clean_me(dd[0]), iconImage = hh[0])
                li.setInfo(type="Video", infoLabels={"plot": clean_me(dd[0])})
                li.setArt({'fanart': hh[0]})
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

            pag = pag + 1
        else:
            break

    xbmcplugin.endOfDirectory(addon_handle)


elif mode[0] == 'show':

    response = browse_this_shit(args['href'][0])

    xx = response.split('contenidorVideosStandAlone/1/')

    if len(xx) > 1:

        pag = 1

        yy = xx[1].split('\'')

        while True:
            
            response = browse_this_shit('https://www.ccma.cat/Comu/standalone/tv3_super3_item_fitxa-programa_videos/contenidor/contenidorVideosStandAlone/' + str(pag) + '/' + yy[0])

            aa = response.split('<a class="media-object"')

            if len(aa) > 1:
                for x in range(1, len(aa)):
                    bb = aa[x].split('<h2')
                    cc = bb[1].split('>')
                    dd = cc[1].split('</h2')

                    ee = aa[x].split('href="')
                    ff = ee[1].split('"')
                    nn = ff[0].split('/')

                    gg = aa[x].split('data-src="')
                    hh = gg[1].split('"')

                    url = build_url({'mode': 'episode', 'title': clean_me(dd[0]), 'href': 'https://dinamics.ccma.cat/pvideo/media.jsp?media=video&versio=1&idint=' + nn[-2] + '&profile=pc&broadcast=false&format=dm'})
                    li = xbmcgui.ListItem(clean_me(dd[0]), iconImage = hh[0])
                    li.setInfo(type="Video", infoLabels={"plot": clean_me(dd[0])})
                    li.setArt({'fanart': hh[0]})
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

                pag = pag + 1
            else:
                break

    else:
        aa = response.split('<a class="media-object"')

        for x in range(1, len(aa)):
            bb = aa[x].split('<h2')
            cc = bb[1].split('>')
            dd = cc[1].split('</h2')

            ee = aa[x].split('href="')
            ff = ee[1].split('"')
            nn = ff[0].split('/')

            gg = aa[x].split('data-src="')
            hh = gg[1].split('"')

            url = build_url({'mode': 'episode', 'title': clean_me(dd[0]), 'href': 'https://dinamics.ccma.cat/pvideo/media.jsp?media=video&versio=1&idint=' + nn[-2] + '&profile=pc&broadcast=false&format=dm'})
            li = xbmcgui.ListItem(clean_me(dd[0]), iconImage = hh[0])
            li.setInfo(type="Video", infoLabels={"plot": clean_me(dd[0])})
            li.setArt({'fanart': hh[0]})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'episode':

    json_data = browse_this_shit(args['href'][0])

    aa = json_data.split('.mp4"')
    bb = aa[0].split('"')

    listitem = xbmcgui.ListItem(args['title'][0])
    listitem.setInfo('video', {'Title': args['title'][0]})
    xbmc.Player().play(bb[-1] + '.mp4', listitem)